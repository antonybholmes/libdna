name = 'libdna'
from libdna.libdna import Loc
from libdna.libdna import DNA2Bit


